import { Stack } from 'expo-router';

export default function AdminLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="admin" />
      <Stack.Screen name="admin-users" />
    </Stack>
  );
}
